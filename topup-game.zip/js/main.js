document.addEventListener("DOMContentLoaded", () => {

  /* ======================
     BANNER SLIDER
  ====================== */
  const slides = document.querySelectorAll(".banner-slide");
  let index = 0;

  if (slides.length > 0) {
    setInterval(() => {
      slides[index].classList.remove("active");
      index = (index + 1) % slides.length;
      slides[index].classList.add("active");
    }, 4000);
  }

  /* ======================
     CATEGORY FILTER
  ====================== */
  const categoryCards = document.querySelectorAll(".category-card");
  const gameCards = document.querySelectorAll(".game-card");

  categoryCards.forEach(card => {
    card.addEventListener("click", () => {
      categoryCards.forEach(c => c.classList.remove("active"));
      card.classList.add("active");

      const filter = card.dataset.filter;

      gameCards.forEach(game => {
        const category = game.dataset.category;
        game.style.display =
          filter === "all" || category === filter ? "block" : "none";
      });
    });
  });

  /* ======================
     SEARCH GAME
  ====================== */
  const searchInput = document.getElementById("searchGame");
  const searchResult = document.getElementById("searchResult");
  const games = document.querySelectorAll(".game-card");

  if (searchInput) {
    searchInput.addEventListener("input", function () {
      const keyword = this.value.toLowerCase();
      searchResult.innerHTML = "";

      if (keyword === "") {
        searchResult.style.display = "none";
        return;
      }

      let found = false;

      games.forEach(game => {
        const title = game.querySelector("h3")?.innerText.toLowerCase();
        const img = game.querySelector("img")?.src;
        const link = game.getAttribute("href");

        if (title && title.includes(keyword)) {
          found = true;
          searchResult.innerHTML += `
            <a href="${link}" class="search-item">
              <img src="${img}">
              <h4>${game.querySelector("h3").innerText}</h4>
            </a>
          `;
        }
      });

      searchResult.style.display = found ? "block" : "none";
    });
  }

  document.addEventListener("click", e => {
    if (!e.target.closest(".search-box")) {
      searchResult.style.display = "none";
    }
  });

});

 /* ======================
   REVIEW SYSTEM
====================== */
const reviewForm = document.getElementById("reviewForm");
const reviewList = document.getElementById("reviewList");

function loadReviews() {
  const reviews = JSON.parse(localStorage.getItem("reviews")) || [];
  reviewList.innerHTML = "";

  reviews.forEach(review => {
    const div = document.createElement("div");
    div.className = "review-card";
    div.innerHTML = `
      <h4>${review.name}</h4>
      <p>${review.text}</p>
    `;
    reviewList.appendChild(div);
  });
}

reviewForm.addEventListener("submit", function (e) {
  e.preventDefault();

  const name = document.getElementById("reviewName").value.trim();
  const text = document.getElementById("reviewText").value.trim();

  if (!name || !text) return;

  const reviews = JSON.parse(localStorage.getItem("reviews")) || [];
  reviews.unshift({ name, text });

  localStorage.setItem("reviews", JSON.stringify(reviews));

  reviewForm.reset();
  loadReviews();
});

loadReviews();